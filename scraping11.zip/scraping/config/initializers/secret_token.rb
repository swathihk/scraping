# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Scraping::Application.config.secret_token = 'ac0025e677bd80b4e86ef5250ad3602d6ddb5a9aaa9e876860354f82ce4f1ad5bcb73a415c569a2e8c8c43c8b4c2fa15a260e5cae4bacea783b9c89b4dae5ada'

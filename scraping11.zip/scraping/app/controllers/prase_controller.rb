class PraseController < ApplicationController
  require 'nokogiri'
  require 'open-uri'
  def index
    @text_value=params[:search]
    urls="http://www.thinkvidya.com/provider/search?city=Hyderabad&keyword=#{@text_value}&area=&freshSearch=true&distance=2"
    docs=Nokogiri::HTML(open(urls))
     @a={}
     
     i=0
     @page=docs.css(".paddingTop20 .step").to_a
    begin 
    @page_last_no=@page.last.text
    rescue
      @page_last_no=1
    end
    
   (1..@page_last_no.to_i).each do |page_no|
     
    url="http://www.thinkvidya.com/provider/search?city=Hyderabad&keyword=#{@text_value}&localityId=&page=#{page_no}&distance=2"
    doc=Nokogiri::HTML(open(url))

     doc.css(".ch-c").each do |item|
       @a[i]={}
      j=0
          begin
            @a[i][j]="#{item.at_css('.marginBtm2')}"
        j=j+1
         rescue
     
     @a[i][j]='No id'
        j=j+1
         end
         begin
            @a[i][j]="#{item.at_css('.border')}"
        j=j+1
         rescue
     
     @a[i][j]='No image'
        j=j+1
         end
         begin
         
         @a[i][j]="#{item.at_css('.loud').text}"
        j=j+1
         rescue
       @a[i][j]='No Name'
      
        j=j+1
         end
         begin
            @a[i][j]="#{item.at_css('.marginBtm2 b').text}"
           
        j=j+1
         rescue
           @a[i][j]='No Location'
        j=j+1
         end
         begin
           @a[i][j]="#{item.at_css('.searchSkillsLinks').text}"
            #@a[i].store(j,item.at_css(".searchSkillsLinks").text
        j=j+1
         rescue
      #@a[i][j]='No Skills'
      @a[i][j]='No Skills'
        j=j+1
         end
         begin
            @a[i][j]="#{item.at_css('.marginTop2 span').text}"
        j=j+1
         rescue
     
     @a[i][j]='No Description'
        j=j+1
         end
        
      i=i+1
      end

     end
     
  end
    
    
end
#name => .loud
#location =>.marginBtm2 b
#skills =>.searchSkillsLinks
#description .marginTop2 span
#image .border img
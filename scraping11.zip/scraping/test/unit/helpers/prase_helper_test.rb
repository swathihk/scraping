require 'test_helper'

class PraseHelperTest < ActionView::TestCase
end
